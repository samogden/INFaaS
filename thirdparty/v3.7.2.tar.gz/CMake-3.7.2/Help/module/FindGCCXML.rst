.. cmake-module:: ../../Modules/FindGCCXML.cmake
